const useEMICalculator = () => {
  const calculateEMI = (principal, annualRate, months) => {
    const monthlyRate = annualRate / 12 / 100;
    const numerator = principal * monthlyRate * Math.pow(1 + monthlyRate, months);
    const denominator = Math.pow(1 + monthlyRate, months) - 1;
    const emi = numerator / denominator;
    return emi ? emi.toFixed(2) : 0;
  };

  return { calculateEMI };
};

export default useEMICalculator;