import React, { useState } from 'react';
import useEMICalculator from '../hooks/useEMICalculator';
import useAmortizationSchedule from '../hooks/useAmortizationSchedule';
import EMICurrencyConverter from './EMICurrencyConverter';
import AmortizationTable from './AmortizationTable';
import { TextField, Button, Typography, Box } from '@mui/material';

const EMICalculator = () => {
  const { calculateEMI } = useEMICalculator();
  const { generateSchedule } = useAmortizationSchedule();

  const [principal, setPrincipal] = useState('');
  const [rate, setRate] = useState('');
  const [months, setMonths] = useState('');
  const [emi, setEmi] = useState(null);
  const [schedule, setSchedule] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const emiVal = calculateEMI(Number(principal), Number(rate), Number(months));
    setEmi(emiVal);
    setSchedule(generateSchedule(Number(principal), Number(rate), Number(months)));
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ maxWidth: 400, mx: 'auto' }}>
      <TextField label="Loan Amount" fullWidth margin="normal" type="number" value={principal} onChange={(e) => setPrincipal(e.target.value)} />
      <TextField label="Annual Interest Rate (%)" fullWidth margin="normal" type="number" value={rate} onChange={(e) => setRate(e.target.value)} />
      <TextField label="Loan Term (Months)" fullWidth margin="normal" type="number" value={months} onChange={(e) => setMonths(e.target.value)} />
      <Button type="submit" variant="contained" sx={{ mt: 2 }}>Calculate EMI</Button>
      {emi && <Typography variant="h6" sx={{ mt: 3 }}>Monthly EMI: ₹ {emi}</Typography>}
      {emi && <EMICurrencyConverter emi={emi} />}
      {schedule.length > 0 && <AmortizationTable schedule={schedule} />}
    </Box>
  );
};

export default EMICalculator;