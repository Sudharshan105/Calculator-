import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableRow, Paper, Typography } from '@mui/material';

const AmortizationTable = ({ schedule }) => {
  if (!schedule?.length) return null;

  return (
    <Paper sx={{ mt: 4, overflowX: 'auto' }}>
      <Typography variant="h6" sx={{ p: 2 }}>Amortization Schedule</Typography>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Month</TableCell>
            <TableCell>EMI</TableCell>
            <TableCell>Principal</TableCell>
            <TableCell>Interest</TableCell>
            <TableCell>Balance</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {schedule.map((row) => (
            <TableRow key={row.month}>
              <TableCell>{row.month}</TableCell>
              <TableCell>{row.emi}</TableCell>
              <TableCell>{row.principalPayment}</TableCell>
              <TableCell>{row.interest}</TableCell>
              <TableCell>{row.remainingBalance}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  );
};

export default AmortizationTable;