import React, { useEffect, useState } from 'react';
import { getExchangeRates } from '../services/exchangeRateService';
import { TextField, MenuItem, Typography } from '@mui/material';

const EMICurrencyConverter = ({ emi }) => {
  const [rates, setRates] = useState({});
  const [currency, setCurrency] = useState('USD');
  const [converted, setConverted] = useState(null);

  useEffect(() => {
    const fetchRates = async () => {
      const data = await getExchangeRates();
      if (data) setRates(data);
    };
    fetchRates();
  }, []);

  useEffect(() => {
    if (emi && rates[currency]) {
      setConverted((emi * rates[currency]).toFixed(2));
    }
  }, [emi, currency, rates]);

  return emi ? (
    <div style={{ marginTop: 20 }}>
      <TextField
        select
        label="Convert EMI to"
        value={currency}
        onChange={(e) => setCurrency(e.target.value)}
        fullWidth
        margin="normal"
      >
        {Object.keys(rates).map((code) => (
          <MenuItem key={code} value={code}>{code}</MenuItem>
        ))}
      </TextField>
      {converted && (
        <Typography variant="subtitle1">
          Converted EMI: {currency} {converted}
        </Typography>
      )}
    </div>
  ) : null;
};

export default EMICurrencyConverter;