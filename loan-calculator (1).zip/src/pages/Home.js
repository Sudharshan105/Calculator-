import React from 'react';
import EMICalculator from '../components/EMICalculator';

const Home = () => (
  <div>
    <h2>Loan EMI Calculator</h2>
    <EMICalculator />
  </div>
);

export default Home;